public enum Player {
    player1, player2, player3, player4
}
