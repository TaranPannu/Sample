import java.util.HashMap;

import javax.swing.JFrame;

public class Game extends JFrame {
    
    public HashMap<Player, String> playerColours;
    public static void main(String args[]) {

        TitleScreen select = new TitleScreen();
        //StopBoard test = new StopBoard(4, Player.player1);
    }
}
