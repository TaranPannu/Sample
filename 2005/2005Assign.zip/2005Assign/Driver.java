
public class Driver
{
	public static void main(String[] args)
	{
		// create a new GUI window
	//	WindowDemo demo = new WindowDemo(10, 10);
	knight demo = new knight(5, 5);// creating 5*5 grid square

	}
}
