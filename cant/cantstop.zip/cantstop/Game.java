import javax.swing.JFrame;

public class Game extends JFrame {
    
    
    public static void main(String args[]) {

selectPlayer ob=new selectPlayer();
    }
}
